#import "NSData+AES.h"
#import <CommonCrypto/CommonCryptor.h>

@implementation NSData (AES)

- (NSData *)AES128EncryptedDataWithKey:(NSData*)key
{
    //NSLog(@"1 CHIAVE: %@", key);
    
    return [self AES128EncryptedDataWithKey:key iv:nil];
}

- (NSData *)AES128DecryptedDataWithKey:(NSData*)key
{
    return [self AES128DecryptedDataWithKey:key iv:nil];
}

- (NSData *)AES128EncryptedDataWithKey:(NSData*)key iv:(NSData*)iv
{
    //NSLog(@"2 CHIAVE: %@", key);
    
    return [self AES128Operation:kCCEncrypt key:key iv:iv];
}

- (NSData *)AES128DecryptedDataWithKey:(NSData*)key iv:(NSData*)iv
{
    return [self AES128Operation:kCCDecrypt key:key iv:iv];
}

- (NSData *)AES128Operation:(CCOperation)operation key:(NSData*)keyData iv:(NSData*)ivData
{
   // NSLog(@"3 CHIAVE: %@", key);
    
    //ORIGINALE
    
    /*char keyPtr[kCCKeySizeAES128 + 1];
    bzero(keyPtr, sizeof(keyPtr));
    [key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];*/
    
    //char keyPtr[kCCKeySizeAES128 + 1];
    //bzero(keyPtr, sizeof(keyPtr));
    //[key getCString:keyPtr maxLength:sizeof(keyPtr) encoding:NSUTF8StringEncoding];

    
    // EMANUELE PRIMA PROVA
    
   // NSLog(@"4 CHIAVE: %@", key);
    
    /*printf("\nLA CHIAVE DURANTE L'OPERATION E': ");
    
    int i = 0;
    
    for(i=0; i< 16; i++)
    {
        printf("%d", keyPtr[i]);
    }
    
    printf("\n");*/
    
    
    // ORIGINALE

    /*char ivPtr[kCCBlockSizeAES128 + 1];
    bzero(ivPtr, sizeof(ivPtr));
    if (iv) {
        [iv getCString:ivPtr maxLength:sizeof(ivPtr) encoding:NSUTF8StringEncoding];
    }*/
    
   // NSLog(@"5 CHIAVE: %@", key);

    NSUInteger dataLength = [self length];
    size_t bufferSize = dataLength + kCCBlockSizeAES128;
    void *buffer = malloc(bufferSize);
    
   // NSLog(@"6 CHIAVE: %@", key);
    
    // kCCOptionPKCS7Padding | kCCOptionECBMode
    
    /*CCCryptorStatus cryptStatus = CCCrypt(operation,
     kCCAlgorithmAES128,
     kCCOptionECBMode,
     keyPtr,
     kCCBlockSizeAES128,
     ivPtr,
     [self bytes],
     dataLength,
     buffer,
     bufferSize,
     &numBytesEncrypted);*/

    size_t numBytesEncrypted = 0;
    CCCryptorStatus cryptStatus = CCCrypt(operation,
                                          kCCAlgorithmAES128,
                                          kCCOptionPKCS7Padding | kCCOptionECBMode,
                                          keyData.bytes,
                                          kCCBlockSizeAES128,
                                          ivData.bytes,
                                          [self bytes],
                                          dataLength,
                                          buffer,
                                          bufferSize,
                                          &numBytesEncrypted);
    
   // NSLog(@"7 CHIAVE: %@", key);
    
    /*printf("\nIL BUFFER CIPHER E': ");
    
    char * prova[bufferSize];
    
    *prova = buffer;
    
    for(i=0; i< bufferSize; i++)
    {
        printf("%d", prova[i]);
    }
    
    printf("\n");*/
    
    if (cryptStatus == kCCSuccess) {
        return [NSData dataWithBytesNoCopy:buffer length:numBytesEncrypted];
    }
    
   // NSLog(@"8 CHIAVE: %@", key);
    
    free(buffer);
    return nil;
}

@end
