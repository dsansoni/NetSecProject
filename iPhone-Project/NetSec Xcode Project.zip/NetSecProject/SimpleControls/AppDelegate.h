//
//  AppDelegate.h
//  SimpleControl
//
//  Created by Cheong on 6/11/12.
//  Copyright (c) 2012 RedBearLab. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TableViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate>
{
    TableViewController *controller;
}

@property (strong, nonatomic) UIWindow *window;

@end
